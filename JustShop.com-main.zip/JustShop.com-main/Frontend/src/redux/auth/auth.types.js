export const LOGIN_REQUEST = "auth/login/request";
export const LOGIN_SUCCESS = "auth/login/success";
export const LOGIN_ERROR = "auth/login/error";
export const LOGOUT = "auth/logout";

