// step 1

export const GET_ADMIN_LOADING = "admin/loading";
export const GET_ADMIN_SUCCESS = "admin/success";
export const GET_ADMIN_ERROR = "admin/error";

export const DELETE_PRODUCT_LOADING = "delete/loading";
export const DELETE_PRODUCT_SUCCESS = "delete/success";
export const DELETE_PRODUCT_ERROR = "delete/error";

export const ADD_PRODUCT_LOADING = "add/loading";
export const ADD_PRODUCT_SUCCESS = "add/success";
export const ADD_PRODUCT_ERROR = "add/error";
