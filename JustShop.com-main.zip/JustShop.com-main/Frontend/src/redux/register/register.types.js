export const REGISTER_REQUEST = "register/request";
export const REGISTER_SUCCESS = "register/success";
export const REGISTER_ERROR = "register/error";