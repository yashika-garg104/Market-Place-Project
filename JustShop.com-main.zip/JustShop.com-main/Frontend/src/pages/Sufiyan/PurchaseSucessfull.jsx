import React from 'react'

const PurchaseSucessfull = () => {
  return (
    <div>
      
    </div>
  )
}

export default PurchaseSucessfull
